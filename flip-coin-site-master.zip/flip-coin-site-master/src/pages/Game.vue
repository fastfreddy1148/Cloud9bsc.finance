<template>
  <div class="container">
    <div class="row">
      <div class="bet" v-if="!mobile">
        <div class="bet-row">
          <div class="numbers">
            <p class="number">{{ getBeatyBalance() }}&nbsp;</p>
            <label for="number">balance</label>
          </div>
          <ButtonAdd text="+ 1000" :click="increaseAmount"/>
        </div>
        <div class="bet-row">
          <div class="numbers">
            <input class="number" type="number" id="number" v-model="amount"/>
            <label for="number">bet</label>
          </div>
          <ButtonAdd text="- 1000" :click="decreaseAmount"/>
        </div>
      </div>
      <div class="bet" v-if="mobile">
        <div class="bet-row">
          <div class="numbers">
            <p class="number">{{ getBeatyBalance() }}&nbsp;</p>
            <label for="number">balance</label>
          </div>
          <div class="numbers">
            <input class="number" type="number" id="numberM" v-model="amount"/>
            <label for="numberM">bet</label>
          </div>
        </div>
        <br>
        <br>
        <div class="bet-row" :style="{flexDirection: 'row'}">
          <ButtonAdd text="- 1000" :click="decreaseAmount"/>
          <ButtonAdd text="+ 1000" :click="increaseAmount"/>
        </div>
      </div>
      <br>
      <br>
      <div class="coin-container">
        <br>
        <Coin/>
        <br>
        <br>
        <Button text="Flip" :click="openChooseTail"/>
      </div>
    </div>
    <div class="overflow" v-if="chooseTail || flipping || result" @click="closeModals"></div>
    <div class="modal" v-if="chooseTail" :style="{ width: '40vw', left: '25vw'}">
      <div class="close" @click="() => {this.chooseTail = false}">✕</div>
      <div class="choose">
        <p class="title">Please choose side</p>
        <div class="switcher">
          <div :class="{'active': !isTail, 'switch': true}" @click="() => this.isTail = false">Heads</div>
          <div :class="{'active': isTail, 'switch': true}" @click="() => this.isTail = true">Tails</div>
        </div>
      </div>
      <PlayableCoin :click="play"/>
    </div>
    <div class="modal" v-if="flipping" :style="{ width: '20vw', left: '35vw', justifyContent: 'center'}">
      <div class="close" @click="() => {this.flipping = false}">✕</div>
      <Coin :startRotate="true"/>
    </div>
    <div class="modal" v-if="result"
         :style="{ width: '50vw', left: '20vw', justifyContent: 'center', flexDirection: 'column'}">
      <div class="close" @click="() => {this.result = false}">✕</div>
      <div class="title result-title" :class="{'is-win': isWin}">
        {{ isWin ? 'Congratulations!' : 'Better luck next time' }}
      </div>
      <div class="sub-title" :class="{'is-win': isWin}">
        {{ isWin ? 'Your winning is' : 'Your lose is' }}
      </div>
      <div class="token-amount">
        {{ awardAmount }}
      </div>
      <div class="buttons">
        <Button text="FLIP" :style="{width: '20vw'}" :click="() => {this.chooseTail = true; this.result = false}"/>
        <Button text="GO BACK" :click="() => {this.result = false}" :alt="true"/>
      </div>
    </div>
  </div>
</template>

<script>
import Coin from "@/components/Coin"
import Button from "@/components/Button"
import ButtonAdd from "@/components/ButtonAdd"
import tokenContract from "@/contracts/token"
import flipCoinContract from "@/contracts/flipCoin"
import Web3 from "web3"
import PlayableCoin from "@/components/PlayableCoin"

export default {
  name: "Game",
  title: 'Cloud9bsc.app',
  data() {
    return {
      chooseTail: false,
      flipping: false,
      result: false,
      account: null,
      web3: null,
      reward: 0,
      bank: 0,
      token: null,
      game: null,
      tokenCount: 0,
      error: '',
      currentBalance: 0,
      amount: 100,
      isTail: false,
      inPlay: false,
      maxBid: 0,
      awardAmount: 0,
      isWin: false,
      mobile: false,
    }
  },
  watch: {
    amount: function (val) {
      if (val > parseFloat(this.maxBid)) {
        this.amount = parseInt(this.maxBid)
        alert(`Max bid is: ${this.maxBid} tokens`)
      }
    }
  },
  methods: {
    getBeatyBalance() {
      const balance = this.currentBalance.toString().split('.')[0]
      // if (balance.length > 6) {
      //   return `${balance.substring(0, balance.length - 6)}M`
      // }
      // if (balance.length > 3) {
      //   return `${balance.substring(0, balance.length - 3)}K`
      // }
      return balance
    },
    closeModals() {
      this.chooseTail = false
      this.flipping = false
      this.result = false
    },
    openChooseTail() {
      this.chooseTail = true
    },
    decreaseAmount() {
      if (this.amount >= 1000) {
        this.amount = parseInt(this.amount) - 1000
      }
    },
    increaseAmount() {
      if (this.amount + 1000 <= parseFloat(this.maxBid)) {
        this.amount = parseInt(this.amount) + 1000
      } else {
        alert(`Max bid is: ${this.maxBid} tokens`)
      }
    },
    async play() {
      this.chooseTail = false
      this.flipping = true
      this.inPlay = true
      const time = Date.now()
      const allowance = await this.token.methods.allowance(this.account, flipCoinContract.address).call()
      const bid = this.web3.utils.toBN(this.amount).mul(this.web3.utils.toBN('1000000000'))

      if (allowance < 1000000) {
        await this.token.methods.approve(flipCoinContract.address, '1000000000000000000000000000000000').send({
          from: this.account
        })
      }

      try {
        const gas = await this.game.methods.play(this.isTail, bid, time).estimateGas({from: this.account})

        console.log(gas)
        const playResult = await this.game.methods.play(this.isTail, bid, time)
        .send({
          from: this.account
        })

        if (playResult.events.Lose) {

          this.isWin = false
          this.awardAmount = this.amount
        } else {
          this.isWin = true
          const balance = this.web3.utils.fromWei(await this.token.methods.balanceOf(this.account).call(), 'gwei').toString().split('.')

          let after = ''
          if (balance[1]) {
            for (let i = 0; i < 4; i++) {
              if(i <= balance[1].length) {
                after += balance[1][i]
              }
            }
          }
          const award = (parseFloat(`${balance[0]}${after ? '.' : ''}${after}`) - parseFloat(this.currentBalance) + parseFloat(this.amount)).toString().split('.')

          after = ''
          if (award[1]) {
            for (let i = 0; i < 2; i++) {
              if(award[1] !== undefined && i <= award[1].length) {
                after += award[1][i]
              }
            }
          }

          this.awardAmount = `${award[0]}${after ? '.' : ''}${after}`
        }

        this.result = true
        this.flipping = false
        this.inPlay = false
        await this.updateCounters()
      } catch (revertReason) {
        const msg = JSON.parse(revertReason.message.replace('Internal JSON-RPC error.', '')).message.replace('execution reverted: ', '')
        const maxBid = await this.game.methods._maxBid().call();
        const balance = await this.token.methods.balanceOf(flipCoinContract.address).call();

        switch (msg) {
          case "The bank is too small":
            alert(`${msg} max bid is: ${this.web3.utils.fromWei((maxBid * balance / 10000).toString(), 'gwei').toString()}`)
            break;
          case "You have insufficient funds":
            alert(`Decrease your bid`)
            break;
          case "You need to hold more tokens to play":
            alert(`You need to hold at least 1000 tokens to play`)
            break;

          default:
            alert(msg);
        }

        this.result = false
        this.flipping = false
        this.inPlay = false
      }
    },
    async initContracts() {
      await window.ethereum.enable()

      this.token = new this.web3.eth.Contract(tokenContract.abi, tokenContract.address)
      this.game = new this.web3.eth.Contract(flipCoinContract.abi, flipCoinContract.address)

      await this.updateCounters()
    },
    async updateCounters() {
      const balance = this.web3.utils.fromWei(await this.token.methods.balanceOf(this.account).call(), 'gwei').toString().split('.')

      let after = ''
      if (balance[1]) {
        for (let i = 0; i < 4; i++) {
          after += balance[1][i]
        }
      }

      this.maxBid = this.web3.utils.fromWei('100000000000', 'wei')
      this.currentBalance = `${balance[0]}${after ? `.${after}` : '.0'}`
    },
  },
  async mounted() {
    this.mobile = window.screen.width <= 600
    this.web3 = new Web3(window.ethereum)
    this.web3.eth.handleRevert = true
    this.account = localStorage.getItem('account')
    await this.initContracts()
  },
  components: {PlayableCoin, ButtonAdd, Button, Coin}
}
</script>

<style scoped lang="scss">
.overflow {
  position: fixed;
  z-index: 1000;
  width: 100vw;
  height: 100vh;
  top: 0;
  left: 0;
  background: #0000007f;
}

.modal {
  position: fixed;
  top: 15vw;
  z-index: 1000000;
  padding: 7vw 5vw;
  background: url("/img/modal-background.png") no-repeat center center;
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;

  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;

  .title {
    font-size: $mediumTextSize;

    &.result-title {
      font-size: $bigTextSize;
      color: #E84747;
      font-weight: bold;
      margin-bottom: 1vw;
    }

    &.is-win {
      color: #00FFA3;
    }
  }

  .sub-title {
    font-size: $smallTextSize;
    margin-bottom: 1vw;

    &.is-win {
      font-size: $mediumTextSize;
    }
  }

  .token-amount {
    font-size: $veryBigTextSize;
    margin-bottom: 1vw;
    font-weight: bold;
    background: linear-gradient(278.22deg, #FFDA19 1.98%, #FFFF70 93.39%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
  }

  .buttons {
    display: flex;
    width: 100%;
    flex-direction: row;
    justify-content: space-between;
  }

  .switcher {
    display: flex;
    flex-direction: row;
    justify-content: center;
    align-items: center;

    .switch {
      cursor: pointer;

      &.active {
        background-color: $blue;
        box-shadow: 0 0 10px #00C2FF;
        color: #ffffff;

        &:hover {
          background-color: $hoveredBlue;
        }
      }

      &:hover {
        background-color: #0000007f;
        color: #FFFFFF8F;
      }

      background-color: #0000003f;
      color: #FFFFFF6F;
      padding: 1vw 4vw;
      font-weight: bold;
      border: 0;
      width: fit-content;
      border-radius: 2px;
      text-transform: uppercase;
      font-size: $mediumTextSize;
    }
  }

  .close {
    top: 1vw;
    cursor: pointer;
    right: 1vw;
    font-size: 20px;
    position: absolute;
    color: #ffffff;
  }
}

.row {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  margin-top: 11vw;

  .coin-container {
    min-width: 22.4vw;
  }

  .bet {
    display: flex;
    flex-direction: column;

    .bet-row {
      display: flex;
      flex-direction: row;
      align-items: center;
      justify-content: space-between;

      .numbers {
        display: flex;
        align-items: center;
        width: 18vw;
        justify-content: flex-start;
        margin-right: 5vw;

        .number {
          background: transparent;
          border: 0;
          color: #ffffff;
          font-size: $bigTextSize;
          font-weight: bold;
          width: 13vw;
          font-family: inherit;
          text-align: right;
        }

        label {
          color: #ffffff4f;
          font-size: $mediumTextSize;
        }

      }
    }
  }
}

@media only screen and (max-width: 600px) {
  .overflow {
    position: fixed;
    z-index: 1000;
    width: 100vw;
    height: 100vh;
    top: 0;
    left: 0;
    background: #0000007f;
  }

  .modal {
    position: fixed;
    top: 25vw;
    z-index: 1000000;
    padding: 10vw 15vw;
    background: url("/img/modal-background.png") no-repeat center center;
    -webkit-background-size: cover;
    -moz-background-size: cover;
    -o-background-size: cover;
    background-size: cover;
    width: 60vw !important;
    left: 5vw !important;

    display: flex;
    flex-direction: column;
    justify-content: space-between;
    align-items: center;

    .title {
      font-size: $mediumTextSize;

      &.result-title {
        font-size: $bigTextSize;
        color: #E84747;
        font-weight: bold;
        margin-bottom: 1vw;
      }

      &.is-win {
        color: #00FFA3;
      }
    }

    .sub-title {
      font-size: $smallTextSize;
      margin-bottom: 1vw;

      &.is-win {
        font-size: $mediumTextSize;
      }
    }

    .token-amount {
      font-size: $veryBigTextSize;
      margin-bottom: 1vw;
      font-weight: bold;
      background: linear-gradient(278.22deg, #FFDA19 1.98%, #FFFF70 93.39%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }

    .buttons {
      display: flex;
      width: 100%;
      flex-direction: column;
      justify-content: space-between;

      .cloud-button {
        width: 100% !important;
        padding: 2vw 5vw;
        margin-bottom: 5vw;
      }
    }

    .switcher {
      display: flex;
      flex-direction: row;
      justify-content: center;
      align-items: center;
      margin-bottom: 15vw;

      .switch {
        cursor: pointer;

        &.active {
          background-color: $blue;
          box-shadow: 0 0 10px #00C2FF;
          color: #ffffff;

          &:hover {
            background-color: $hoveredBlue;
          }
        }

        &:hover {
          background-color: #0000007f;
          color: #FFFFFF8F;
        }

        background-color: #0000003f;
        color: #FFFFFF6F;
        padding: 1vw 4vw;
        font-weight: bold;
        border: 0;
        width: fit-content;
        border-radius: 2px;
        text-transform: uppercase;
        font-size: $mediumTextSize;
      }
    }

    .close {
      top: 1vw;
      cursor: pointer;
      right: 1vw;
      font-size: 20px;
      position: absolute;
      color: #ffffff;
    }
  }

  .row {
    display: flex;
    align-items: center;
    flex-direction: column;
    padding: 4vw;
    margin-top: 5vw;
    justify-content: flex-start;

    .coin-container {
      min-width: 22.4vw;
    }

    .bet {
      display: flex;
      flex-direction: column;

      .bet-row {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: space-between;

        .numbers {
          display: flex;
          align-items: center;
          width: 80vw;
          justify-content: center;
          margin-right: 0vw;

          .number {
            background: transparent;
            border: 0;
            color: #ffffff;
            font-size: $bigTextSize;
            font-weight: bold;
            width: 30vw;
            font-family: inherit;
            text-align: right;
          }

          label {
            color: #ffffff4f;
            font-size: $mediumTextSize;
            width: 20vw;
            text-align: left;
          }

        }
      }
    }
  }
}
</style>