<template>
  <div class="container">
    <img src="@/assets/img/logo_big.png" alt="logo" class="logo"/>
    <Button :click="connectMetamask" text="unlock wallet"/>
  </div>
</template>

<script>
import Button from "@/components/Button";
export default {
  name: "Login",
  components: {Button},
  title: 'Cloud9bsc.app',
  methods: {
    async connectMetamask() {
      const accounts = await window.ethereum.request({method: 'eth_requestAccounts'});
      if(accounts[0]) {
        localStorage.setItem('account', accounts[0]);
        window.isLogged = true
        this.$router.push({ name: 'home' });
      }
    }
  }
}
</script>

<style scoped lang="scss">
.container {
  display: flex;
  flex-direction: column;
  align-items: center;
  .logo {
    width: 70%;
    margin: 5vw auto 4vw;
  }
}
@media only screen and (max-width: 600px) {
  .container {
    .logo {
      width: 90%;
      margin: 45vw auto 14vw;
    }
  }
}
</style>