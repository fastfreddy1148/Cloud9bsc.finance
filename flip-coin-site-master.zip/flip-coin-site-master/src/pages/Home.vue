<template>
  <div class="container-home">
    <div class="row">
      <WalletInformation title="Wallet information"
                         :item="[{ number: entries, text: 'Entries', icon: 'ticket' }, { number: draws, text: 'Draws', icon: 'team' }]"/>
      <WalletInformation title=""
                         :item="[{ number: `${chance}%`, text: 'Chance to win', icon: 'percent' }, { number: bnb, text: 'BNB', icon: 'bnb' }]"/>
    </div>
    <div class="row" >
      <Lottery/>
      <div class="coin-container">
        <br>
        <br>
        <br>
        <Coin/>
        <br>
        <br>
        <Button text="Flip" :click="() => this.$router.push({name: 'game'})"/>
      </div>
    </div>
  </div>
</template>

<script>
import WalletInformation from "@/components/WalletInformation";
import Lottery from "@/components/Lottery";
import Coin from "@/components/Coin";
import Button from "@/components/Button";
import Web3 from "web3";
import tokenContract from "@/contracts/token";
import flipCoinContract from "@/contracts/flipCoin";
import pair from "@/contracts/pair";

export default {
  name: "Home",
  components: {Button, Coin, Lottery, WalletInformation},
  title: 'Cloud9bsc.app',
  data: () => ({
    web3: null,
    chance: 0,
    account: '',
    bnb: 0,
    entries: 0,
    draws: 0,
    token: null,
    game: null,
    pair: null,
    error: '',
  }),
  methods: {
    async initContracts() {
      await window.ethereum.enable();

      this.token = new this.web3.eth.Contract(tokenContract.abi, tokenContract.address);
      this.game = new this.web3.eth.Contract(flipCoinContract.abi, flipCoinContract.address);
      const pairAddress = await this.token.methods.pancakeswapV2Pair().call();

      this.pair = new this.web3.eth.Contract(pair.abi, pairAddress);
      await this.updateCounters()
    },
    async updateCounters() {
      this.updateAward();
      this.updateDraws();

    },
    async updateAward() {
      const rewardSize = await this.token.methods._currentGiveAwayBNB().call();
      const tokenSize = await this.token.methods._currentPromo().call();
      const rewardFee = await this.token.methods.getRewardSize().call();
      const promoFee = await this.token.methods._giveawayFee().call();

      let tokenAmount = this.web3.utils.toBN(tokenSize).div(this.web3.utils.toBN(promoFee)).mul(this.web3.utils.toBN(rewardFee))
      const rates = await this.pair.methods.getReserves().call();
      let tokenInBnb = tokenAmount.mul(this.web3.utils.toBN(rates['_reserve1'])).div((this.web3.utils.toBN(rates['_reserve0'])))
      const award = this.web3.utils.fromWei(this.web3.utils.toBN(rewardSize).add(tokenInBnb)).toString().split('.')

      let after = '';
      for (let i = 0; i < 4; i++) {
        after += award[1][i];
      }

      this.bnb = `${award[0]}.${after}`
    },
    async updateDraws() {
      const currentDraw = await this.token.methods._currentStartIndex().call();

      this.token.methods._participantsEntries(this.account, currentDraw).call().then(async (res) => {
        this.entries = res
        this.chance = parseInt((this.entries / await this.token.methods.getParticipantCount().call()) * 100);
      })

      for (let i = currentDraw; i < 53 + currentDraw; i++) {
        try {
          const res = await this.token.methods._participantsEntries(this.account, i).call()
          if(res > 0) {
            this.draws = this.draws + 1
          } else {
            i = 53 + currentDraw
          }
        } catch (e) {
          i = 53 + currentDraw
        }
      }
    }
  },
  async mounted() {
    this.web3 = new Web3(window.ethereum);
    this.account = localStorage.getItem('account')
    await this.initContracts()
  }
}
</script>

<style scoped lang="scss">
.container-home {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  .row {
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    align-items: center;
    margin-top: 5vw;

    .coin-container {
      min-width: 22.4vw;
    }
  }
}

@media only screen and (max-width: 600px) {
  .container-home {
    display: flex;
    flex-direction: column;
    justify-content: space-between;

    .row {
      flex-direction: column;
      padding: 4vw;
    }
  }
}
</style>