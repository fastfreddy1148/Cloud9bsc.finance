import Home from "@/pages/Home";
import Login from "@/pages/Login";
import Game from "@/pages/Game";

export const routes = [
  {
    path: '/',
    name: 'home',
    meta: {
      requiresAuth: true
    },
    component: Home
  },
  {
    path: '/auth',
    name: 'login',
    component: Login
  },
  {
    path: '/game',
    name: 'game',
    meta: {
      requiresAuth: true
    },
    component: Game
  },
  {
    path: '/info',
    name: 'info',
    component: Login
  }
]
