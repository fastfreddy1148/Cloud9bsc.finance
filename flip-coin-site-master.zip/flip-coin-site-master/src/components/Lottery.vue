<template>
  <div class="container">
    <RadialProgressBar
        :diameter="diameter"
        :completed-steps="completedSteps"
        :total-steps="totalSteps"
        :strokeWidth="15"
        innerStrokeColor="#0000002F"
        startColor="#00C2FF"
        stopColor="#00C2FF"
    >
      <p class="title">Left until the giveaway</p>
      <div class="timer">
        <div class="section">
          <div class="number">
            {{ daysLeft }}
          </div>
          <div class="label">
            days
          </div>
        </div>
        <span class="separator">:</span>
        <div class="section">
          <div class="number">
            {{ hoursLeft }}
          </div>
          <div class="label">
            hours
          </div>
        </div>
        <span class="separator">:</span>
        <div class="section">
          <div class="number">
            {{ minutesLeft }}
          </div>
          <div class="label">
            minutes
          </div>
        </div>
        <span class="separator">:</span>
        <div class="section">
          <div class="number">
            {{ secondsLeft }}
          </div>
          <div class="label">
            seconds
          </div>
        </div>
      </div>
    </RadialProgressBar>
  </div>
</template>

<script>
import RadialProgressBar from 'vue-radial-progress'

export default {
  data() {
    return {
      totalSteps: 7 * 24 * 60 * 60,
      lastTime: 0
    }
  },
  methods: {
    dateOfNearestDay(startingDate, nearestDay) {
      const nearestTime = new Date(startingDate.getTime());

      if (startingDate.getDay() === 6 && nearestDay === 5) {
        nearestTime.setDate((startingDate.getDate() +
            (7 + nearestDay - startingDate.getDay()) % 7) - 7);
      } else {
        nearestTime.setDate(startingDate.getDate() +
            (7 + nearestDay - startingDate.getDay()) % 7);
      }

      return nearestTime;
    }
  },
  computed: {
    diameter() {
      return window.screen.width > 600 ? window.screen.width / 4.5 : window.screen.width / 1.2;
    },
    completedSteps() {
      this.lastTime;
      const today = new Date();
      today.setHours(23);
      today.setMinutes(59);
      today.setSeconds(59);
      const nextLottery = this.dateOfNearestDay(today, 5).getTime()

      return (nextLottery - (Date.now())) / 1000;
    },
    daysLeft() {
      return Math.floor(this.completedSteps / (24 * 60 * 60)).toString().padStart(2, 0)
    },
    hoursLeft() {
      return Math.floor((this.completedSteps - (24 * 60 * 60 * this.daysLeft)) / (60 * 60)).toString().padStart(2, 0)
    },
    minutesLeft() {
      return Math.floor((this.completedSteps - (24 * 60 * 60 * this.daysLeft) - (60 * 60 * this.hoursLeft)) / 60).toString().padStart(2, 0)
    },
    secondsLeft() {
      return Math.floor(this.completedSteps - (24 * 60 * 60 * this.daysLeft) - (60 * 60 * this.hoursLeft) - (60 * this.minutesLeft)).toString().padStart(2, 0)
    }
  },
  mounted() {
    setInterval(() => {
      this.lastTime++;
    }, 300)
  },

  components: {
    RadialProgressBar
  }
}
</script>

<style scoped lang="scss">
.container {
  display: flex;
  justify-content: center;
  align-items: center;
  .title {
    font-size: $mediumTextSize;
  }

  .timer {
    width: calc(100% - 5vw);
    display: flex;
    justify-content: space-between;
    align-items: center;

    .separator {
      font-size: $biggerTextSize;
      color: #ffffff4f;
      padding-bottom: 1.5vw;
    }

    .section {
      .number {
        background: linear-gradient(278.22deg, #FFDA19 1.98%, #FFFF70 93.39%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        font-size: $biggerTextSize;
        font-weight: bold;
      }

      .label {
        color: #ffffff4f;
      }
    }
  }
}
@media only screen and (max-width: 600px) {
  .container {
    display: flex;
    justify-content: center;
    align-items: center;
    .title {
      font-size: $mediumTextSize;
    }

    .timer {
      width: calc(100% - 20vw);

      .separator {
        font-size: $bigTextSize;
        padding-bottom: 5.5vw;
      }

      .section {
        .number {
          font-size: $bigTextSize;
        }

        .label {
        }
      }
    }
  }
}
</style>