<template>
  <div class="container">
    <img src="@/assets/img/tap_coin.png" class="coin" alt="coin" @click="click">
  </div>
</template>

<script>
export default {
  name: "PlayableCoin",
  props: {
    click: Function
  }
}
</script>

<style scoped lang="scss">
.container {
  .coin {
    cursor: pointer;
    //transition: all 0.2s;
  }
}
</style>