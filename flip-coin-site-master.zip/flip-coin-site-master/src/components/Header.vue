<template>
  <div class="header">
    <div class="logo-container">
      <img class="logo" src="@/assets/img/logo_icon.png" alt="logo">
    </div>
    <div class="menu">
      <router-link :to="{ name: 'home' }" class="menu-link"><span>Home</span></router-link>
      <router-link :to="{ name: 'game' }" class="menu-link">CloudFlip</router-link>
      <a href="http://cloud9bsc.finance/" class="menu-link">Info</a>
    </div>
  </div>
</template>

<script>
export default {
  name: "Header"
}
</script>

<style scoped lang="scss">
.header {
  display: flex;
  flex-direction: row;
  margin-top: 2vw;
  justify-content: space-between;
  align-items: flex-end;
  letter-spacing: 0.25vw;

  .menu {
    &-link {
      text-decoration: none;
      color: #fff;
      font-size: $mediumTextSize;
      margin: 0 1vw;
      text-transform: uppercase;
      &.router-link-exact-active {
        background: linear-gradient(278.22deg, #FFDA19 1.98%, #FFFF70 93.39%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
      }
    }
  }

  .logo-container {
    .logo {

    }
  }
}

@media only screen and (max-width: 600px) {
  .header {
    padding: 4vw;
    align-items: center;

    .menu {
      &-link {
        font-size: $smallTextSize;
        margin: 0 2vw;
      }
    }

    .logo-container {
      .logo {
        width: 17vw;
      }
    }
  }
}
</style>