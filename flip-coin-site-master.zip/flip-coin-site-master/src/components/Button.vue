<template>
  <button @click="click" class="cloud-button" :class="{'alt': alt }">{{ text }}</button>
</template>

<script>
export default {
  name: "Button",
  props: {
    click: Function,
    text: String,
    alt: Boolean
  }
}
</script>

<style scoped lang="scss">
.cloud-button {
  background-color: $blue;
  box-shadow: 0 0 10px #00C2FF;
  padding: 1vw 7vw;
  color: #ffffff;
  font-weight: bold;
  border: 0;
  width: fit-content;
  border-radius: 2px;
  text-transform: uppercase;
  font-size: $mediumTextSize;
  &.alt {
    background-color: #1F4094;
    box-shadow: 0 0 10px #00C2FF;
    color: $blue;
  }
  &:hover{
    cursor: pointer;
    color: #e8e8e8;
    background-color: $hoveredBlue;
  }
}
@media only screen and (max-width: 600px) {
  .cloud-button {
    padding: 4vw 14vw;
  }

}
</style>