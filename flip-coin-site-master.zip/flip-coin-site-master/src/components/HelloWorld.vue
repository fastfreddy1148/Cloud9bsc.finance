<template>
  <div class="hello">
    <button @click="connectMetamask" v-if="account === null">Connect Metamask</button>
    <p>{{ error }}</p>
    <div v-if="account !== null">
      <p>Your account is: {{ account }}</p>
      <p>Bank is: {{ bank }}</p>
      <p>Max bid is: {{ maxBid }}</p>
      <p>Your current balance is: {{ web3.utils.fromWei(currentBalance.toString(), 'gwei') }}</p>
      <hr>
      <br>
      <div v-if="inPlay === false">
        <input type="number" v-model="amount"/>
        <label for="isTail">Is Tail</label>
        <input id="isTail" type="checkbox" v-model="isTail">
        <button @click="play">Play</button>
      </div>
      <div v-if="inPlay === true">
        <img src="@/assets/coinAnimation.gif"/>
      </div>
    </div>
  </div>
</template>

<script>
import Web3 from 'web3';
import tokenContract from '@/contracts/token'
import flipCoinContract from '@/contracts/flipCoin'

export default {
  name: 'HelloWorld',
  components: {},
  props: {
    msg: String
  },
  data() {
    return {
      account: null,
      web3: null,
      bank: 0,
      token: null,
      game: null,
      tokenCount: 0,
      error: '',
      currentBalance: 0,
      amount: null,
      isTail: false,
      inPlay: false,
      maxBid: 0
    }
  },
  methods: {
    async connectMetamask() {
      const accounts = await window.ethereum.request({method: 'eth_requestAccounts'});
      this.account = accounts[0]
      this.web3 = new Web3(window.ethereum);
      await this.initContracts()
    },
    async allowTokens() {
      const deposit = this.web3.utils.toBN(this.tokenCount).mul(this.web3.utils.toBN('1000000000'));
      const allowance = await this.token.methods.allowance(this.account, flipCoinContract.address).call();

      if (this.web3.utils.toBN(allowance) < deposit) {
        const approveResult = await this.token.methods.approve(flipCoinContract.address, '10000000000000000000000000000').send({
          from: this.account
        });
        console.log({
          approveResult,
        })
      }
      const depositResult = await this.game.methods.makeDeposit(deposit).send({
        from: this.account
      });

      if (!depositResult.status) {
        alert('Transaction failed');
        this.error = JSON.stringify(depositResult);
      }
      console.log({
        depositResult
      })
      await this.updateCounters()
    },
    async play() {
      this.inPlay = true
      const time = Date.now();
      const allowance = await this.token.methods.allowance(this.account, flipCoinContract.address).call();
      const bid = this.web3.utils.toBN(this.amount).mul(this.web3.utils.toBN('1000000000'))

      if (this.web3.utils.toBN(allowance) < bid) {
        const approveResult = await this.token.methods.approve(flipCoinContract.address, '10000000000000000000000000000').send({
          from: this.account
        });
        console.log({
          approveResult,
        })
      }

      const playResult = await this.game.methods.play(this.isTail, bid, time)
          .send({
            from: this.account
          });
      console.log({playResult})

      if (playResult.events.Lose) {
        alert('You lose')
      } else {
        alert('You win!')
      }
      this.inPlay = false
      await this.updateCounters()
    },
    async initContracts() {
      await window.ethereum.enable();

      this.token = new this.web3.eth.Contract(tokenContract.abi, tokenContract.address);
      this.game = new this.web3.eth.Contract(flipCoinContract.abi, flipCoinContract.address);
      await this.updateCounters()
    },
    async updateCounters() {
      this.currentBalance = await this.token.methods.balanceOf(this.account).call();
      const bank = this.web3.utils.toBN(await this.game.methods._tokenBank().call());
      const maxBid = await this.game.methods._maxBid().call();

      this.maxBid = this.web3.utils.fromWei(bank.mul(this.web3.utils.toBN(maxBid)).div(this.web3.utils.toBN('10000')), 'gwei')
      this.bank = this.web3.utils.fromWei(bank, 'gwei')
    }
  },
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

a {
  color: #42b983;
}
</style>
