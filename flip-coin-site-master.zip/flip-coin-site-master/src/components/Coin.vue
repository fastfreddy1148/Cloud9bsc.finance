<template>
  <div class="container">
    <img src="@/assets/img/coin.png" class="coin" alt="coin" :style="{transform: `rotateY(${rotation}deg)`}"
         @click="rotate">
  </div>
</template>

<script>
export default {
  name: "Coin",
  props: {
    startRotate: Boolean
  },
  data: () => ({
    counter: 0,
    speed: 150,
    rotationInterval: null
  }),
  computed: {
    rotation() {
      return (this.counter % 60 + 1) * 6 * (this.speed / 100) - 25;
    }
  },
  methods: {
    rotate() {
      if(!this.startRotate) {
        const fps = 60
        this.counter = 0;

        clearInterval(this.rotationInterval)

        this.rotationInterval = setInterval(() => {
          this.counter++
        }, 1000 / fps)

        setTimeout(() => {
          clearInterval(this.rotationInterval)
        }, 700)
      }
    }
  },
  mounted() {
    if(this.startRotate) {
      const fps = 60
      this.counter = 0;

      clearInterval(this.rotationInterval)

      this.rotationInterval = setInterval(() => {
        this.counter++
      }, 1000 / fps)
    }
  }
}
</script>

<style scoped lang="scss">
.container {
  .coin {
    cursor: pointer;
    //transition: all 0.2s;
  }

}
</style>