<template>
  <div>
    <div class="title">
      {{ title }}
    </div>
    <div class="container">
      <div class="item">
        <div class="icon-container">
          <img :src="require(`@/assets/img/${item[0].icon}.png`)" :alt="item[0].icon" class="icon"/>
        </div>
        <p class="number">{{ item[0].number }}</p>
        <p class="text">{{ item[0].text }}</p>
      </div>
      <div class="item">
        <div class="icon-container">
          <img :src="require(`@/assets/img/${item[1].icon}.png`)" :alt="item[0].icon" class="icon"/>
        </div>
        <p class="number">{{ item[1].number }}</p>
        <p class="text">{{ item[1].text }}</p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "WalletInformation",
  props: {
    title: String,
    item: Array
  }
}
</script>

<style scoped lang="scss">
.title {

  background: linear-gradient(278.22deg, #FFDA19 1.98%, #FFFF70 93.39%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  font-size: $bigTextSize;
  font-weight: 700;
}

.container {
  display: flex;
  flex-direction: row;
  justify-content: space-around;
  align-items: flex-start;

  .item {
    margin: 2vw;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    .icon-container {
      border-radius: 100%;
      background-color: rgba(255, 255, 255, 0.05);
      width: 4vw;
      height: 4vw;
      display: flex;
      align-items: center;
      padding: 2vw;

      .icon {
        width: 100%;
      }
    }

    .number {
      font-size: $biggerTextSize;
      color: #ffffff;
      font-weight: bold;
      margin: 0.6vw 0;
    }

    .text {
      color: $fontAddColor;
      margin: 0;

    }
  }
}

@media only screen and (max-width: 600px) {
  .container {
    .item {
      margin: 10vw;
      width: 30vw;
      .icon-container {
        width: 10vw;
        height: 10vw;
        padding: 8vw;

        .icon {
          width: 100%;
        }
      }

      .number {
        font-size: $bigTextSize;
        margin: 0.6vw 0;
      }

      .text {
        margin: 0;
      }
    }
  }
}
</style>