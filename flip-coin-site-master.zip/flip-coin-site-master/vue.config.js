module.exports = {
    css: {
        loaderOptions: {
            sass: {
                additionalData: `
                @import "@/styles/scss/helpers/mixins.scss";
                @import "@/styles/scss/helpers/variables.scss";
                `
            }
        }
    }
};
