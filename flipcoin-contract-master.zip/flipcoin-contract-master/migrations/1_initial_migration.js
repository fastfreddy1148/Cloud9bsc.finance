const FlipCoinGame = artifacts.require("FlipCoinGame");

module.exports = function (deployer) {
    deployer.deploy(
        FlipCoinGame,
        "0xC4596459aA72a2d81BaAbFE788C36329CbDC3af0",
        "0xE1af6f4e0D2753749120a825632b6ECC11012280"
    )
    // deployer.deploy(
    //     ERC20Token,
    //     "Cloud9bsc.finance", //name
    //     "CLOUD9", // symbol
    //     9, // decimals
    //     // supply    // decimals
    //     "99999999000000000", //initialSupply
    //     "0x26742b974e910391Ed970cB9bb39dfa69784dDb5", //promoPoolAddress
    //     "0x53bc04198D7BE53Bc298433d28B2b64E838225e0", // tokenOwnerAddress
    //     "0x10ed43c718714eb63d5aa57b78b54704e256024e",
    // );
};
