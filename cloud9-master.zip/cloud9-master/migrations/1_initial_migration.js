const ERC20Token = artifacts.require("ERC20Token");

const routerAddress = "0xD99D1c33F9fC3444f8101754aBC46c52416550D1";
const lpSize = "100" + "000000000";

module.exports = function (deployer) {
    // deployer.deploy(
    //     ERC20Token,
    //     "Cloud9 Token", //name
    //     "CNT", // symbol
    //     9, // decimals
    //     // supply    // decimals
    //     "999999999" + "000000000", //initialSupply
    //     "0x70173D1Db61B3994eF5D09275967D2a48E41C22f", //promoPoolAddress
    //     "0xC4596459aA72a2d81BaAbFE788C36329CbDC3af0", // tokenOwnerAddress
    //     routerAddress
    // ).then(contract => {
    //     ERC20Token.at(contract.address).then(
    //         async ERC20TokenSmartContract => {
    //             let result = await ERC20TokenSmartContract.approve(
    //                 routerAddress,
    //                 lpSize
    //             ).then(
    //                 function (result) {
    //                     console.log(result)
    //                 }
    //             )
    //         })
    // });
    deployer.deploy(
        ERC20Token,
        "Cloud9bsc.finance", //name
        "CLOUD9", // symbol
        9, // decimals
        // supply    // decimals
        "999999999000000000", //initialSupply
        "0x70173D1Db61B3994eF5D09275967D2a48E41C22f", //promoPoolAddress
        "0xC4596459aA72a2d81BaAbFE788C36329CbDC3af0", // tokenOwnerAddress
        "0x10ed43c718714eb63d5aa57b78b54704e256024e",
    );
};
