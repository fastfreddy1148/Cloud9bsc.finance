var web3 = require('web3');

var winnerLink = 'https://cloud9bsc.finance/get-reward/';

const checkMessage = (entries, entries1, entries2) => `You have ${entries} chances to win in the upcoming giveaway and ${entries1} in the next!! Good luck!!`

const quickCheckMessage = (participantCount, rewardSize) => `Current total entries: ${participantCount}\r\nCurrent reward amount:  ~${web3.utils.fromWei(rewardSize)} BNB`

const chanceMessage = (entries, participantCount) => `Your chance of winning is ${entries / participantCount * 100}%!! Good luck!! `

const winnerMessage = (winner, rewardSize) => `THE  WINNER IS:\r\n 🏆${winner}🏆 \r\n💰His reward is: ${web3.utils.fromWei(rewardSize)} BNB💰 \r\n\r\nFollow this link to get or sacrifice your reward ${winnerLink}`

const isParticipantMessage = () => `Your in!!`;

const notIsParticipantMessage = () => `Every .1 is a chance to win, 4 times!!`;

const winnerSacrificeReward = () => `Winner decided to sacrifice his reward!\r\n\r\nWelcome to the ☁️cloud9club☁️!! Buckle up!!`

const winnerTakeReward = () => `Congrats winner🏆!! Thanks for supporting cloud9!! Your reward will be sent ASAP💰!!`

const supportLinks = () => `WEBSITE: cloud9bsc.finance\r\nTELEGRAM: https://t.me/joinchat/vuteBCdKnV42MjEx\r\nTWITTER: https://twitter.com/BscCloud9\r\nBSCSCAN: https://bscscan.com/token/0xE1af6f4e0D2753749120a825632b6ECC11012280\r\nCONTRACT: 0xE1af6f4e0D2753749120a825632b6ECC11012280`

module.exports = {
  checkMessage,
  quickCheckMessage,
  chanceMessage,
  winnerMessage,
  winnerSacrificeReward,
  winnerTakeReward,
  isParticipantMessage,
  notIsParticipantMessage,
  supportLinks
}